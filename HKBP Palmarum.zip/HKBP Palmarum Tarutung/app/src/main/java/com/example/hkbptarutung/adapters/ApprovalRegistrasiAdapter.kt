package com.example.hkbptarutung.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.hkbptarutung.databinding.ItemApprovalBinding
import com.example.hkbptarutung.model.ApprovalItem

class ApprovalRegistrasiAdapter(private val listItem: List<ApprovalItem>): RecyclerView.Adapter<ApprovalRegistrasiAdapter.ListViewHolder>() {

    class ListViewHolder(val binding: ItemApprovalBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val binding = ItemApprovalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }

    override fun getItemCount(): Int = listItem.size

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val item = listItem[position]
        holder.binding.tvPersonName.text = item.person
        holder.binding.tvRegistrasiType.text = item.type
    }
}