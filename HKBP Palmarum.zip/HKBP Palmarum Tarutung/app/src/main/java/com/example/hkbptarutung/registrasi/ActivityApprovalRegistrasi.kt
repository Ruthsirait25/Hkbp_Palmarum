package com.example.hkbptarutung.registrasi

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hkbptarutung.adapters.ApprovalRegistrasiAdapter
import com.example.hkbptarutung.databinding.ActivityApprovalRegistrasiBinding
import com.example.hkbptarutung.model.ApprovalItem

class ActivityApprovalRegistrasi : AppCompatActivity() {

    lateinit var binding: ActivityApprovalRegistrasiBinding
    lateinit var adapter: ApprovalRegistrasiAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityApprovalRegistrasiBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupRecyclerView()
        binding.ivBtnBack.setOnClickListener {
            finish()
        }
    }

    private fun setupRecyclerView() {
        val items = ArrayList<ApprovalItem>()
        val msg = intent?.extras?.getString("type") ?: "Null"
        for(i in 0..19) {
            items.add(ApprovalItem(type = " ~ Pengajuan $msg"))
        }
        adapter = ApprovalRegistrasiAdapter(items)
        binding.rvApproval.layoutManager = LinearLayoutManager(this)
        binding.rvApproval.adapter = adapter
    }
}