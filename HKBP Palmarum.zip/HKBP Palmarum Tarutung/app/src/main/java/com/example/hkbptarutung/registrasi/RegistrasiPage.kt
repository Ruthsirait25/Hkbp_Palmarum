package com.example.hkbptarutung.registrasi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.example.hkbptarutung.home.HomeJemaat
import com.example.hkbptarutung.Profile
import com.example.hkbptarutung.R

class RegistrasiPage : AppCompatActivity() {

    var layout = R.layout.activity_registrasi_calon_mempelai
    var hideView = -1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initLayout()
        setContentView(layout)
        supportActionBar?.hide()
        findViewById<TextView>(R.id.tv_registrasi_title).text = titleString()
        setupAdapter()
        setupListener()
        hideView()
    }

    private fun hideView() = if (hideView == -1) println("oke") else findViewById<View>(hideView).visibility = View.GONE

    private fun titleString(): String = intent?.extras?.getString("title") ?: "Registrasi"

    private fun initLayout() {
        when (titleString()) {
            getString(R.string.registrasi_baptis) -> {
                layout = R.layout.activity_registrasi_page
                hideView = R.id.ll_tanggal_sidi
            }

            getString(R.string.registrasi_sidi) -> {
                layout = R.layout.activity_registrasi_page
            }

            getString(R.string.registrasi_martupol) -> {
                layout = R.layout.activity_registrasi_calon_mempelai
                hideView = R.id.ll_jekel
            }

            getString(R.string.registrasi_pemberkatan_nikah) -> {
                layout = R.layout.activity_registrasi_other
                hideView = R.id.ll_gereja
            }

            getString(R.string.registrasi_jemaat_baru) -> {
                layout = R.layout.activity_registrasi_other
                hideView = R.id.ll_gereja
            }

            getString(R.string.registrasi_pindah_huria) -> {
                layout = R.layout.activity_registrasi_other
            }
        }
    }

    private fun setupListener() {
        findViewById<View>(R.id.btn_lanjut).setOnClickListener {
            AlertDialog.Builder(this).apply {
                setTitle(getString(R.string.registrasiKegiatan))
                setMessage("Registrasi kegiatan sudah ditambahkan, silahkan tunggu")
                setPositiveButton("Ya") { _, _ ->
                    finish()
                }
            }.create().show()
        }

        findViewById<View>(R.id.btn_batal).setOnClickListener {
            finish()
        }
        findViewById<View>(R.id.iv_btn_back).setOnClickListener {
            finish()
        }
        findViewById<View>(R.id.ll_home).setOnClickListener {
            finishAffinity()
            startActivity(Intent(this, HomeJemaat::class.java))
        }

        findViewById<View>(R.id.ll_profile).setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }
    }

    private fun setupAdapter() {
        ArrayAdapter.createFromResource(
            this, R.array.jenisKelamin, android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            if (layout != R.string.registrasi_martupol) {
                findViewById<Spinner>(R.id.sp_jekel).adapter = adapter
            }
        }
    }
}