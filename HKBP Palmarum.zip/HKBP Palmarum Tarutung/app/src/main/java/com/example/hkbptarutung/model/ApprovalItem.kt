package com.example.hkbptarutung.model

data class ApprovalItem(
    var person: String = "Riana Sianturi",
    var type: String = "Pengajuan Administrasi Baptis"
)