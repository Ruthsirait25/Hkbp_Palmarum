package com.example.hkbptarutung

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class NotifikasiPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifikasi_page)
    }
}