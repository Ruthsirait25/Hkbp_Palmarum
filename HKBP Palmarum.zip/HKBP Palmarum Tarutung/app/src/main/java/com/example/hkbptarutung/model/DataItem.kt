package com.example.hkbptarutung.model

data class DataItem(
    var item: String
)
