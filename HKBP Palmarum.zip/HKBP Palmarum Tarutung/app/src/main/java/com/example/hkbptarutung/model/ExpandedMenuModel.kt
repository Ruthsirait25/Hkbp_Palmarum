package com.example.hkbptarutung.model
class ExpandedMenuModel {
    var iconName = ""
    var iconImg = -1 // menu icon resource id
}